import sys
import time

def main():
    print("Press Enter to show more stuff or type 'exit' to quit. (Most stuff still in testing)")
    while True:
        user_input = input()
        if user_input.lower() == 'exit':
            sys.exit("Goodbye!")
        elif user_input == '':
            # Show more stuff
            print("\nBooters/Stressers")
            print("    ")
            time.sleep(0.1)  # Just to simulate some processing time
            print("https://www.stressthem.se/hub")
            time.sleep(0.1)
            print("https://stresse.ru/")
            time.sleep(0.1)
            print("https://stresser.su/")
            print("\nDoxxing")
            time.sleep(0.1)
            print("    ")
            time.sleep(0.1)
            print("Doxbin.org")
            time.sleep(0.1)
            print("Doxbin.com")
            time.sleep(0.1)
            print("https://peoplelooker.com")
            time.sleep(0.1)
            print("https://www.verifythem.com")
            time.sleep(0.1)
            print("https://www.truthfinder.com")
            print("\nPirating")
            time.sleep(0.1)
            print("    ")
            time.sleep(0.1)
            print(" (Not trusted) https://Steamunlocked.com")
            time.sleep(0.1)
            print("(Not Trusted) https://PiratedGames.com")
            
            print("\nPress Enter to show more stuff or type 'exit' to quit.")
        else:
            print("Invalid input. Press Enter to show more stuff or type 'exit' to quit.")

if __name__ == "__main__":
    main()

    


            
